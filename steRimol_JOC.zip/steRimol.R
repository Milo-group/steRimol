xyz_file_generator <- function(dir) {
  options(scipen = 999)
  setwd(dir)
  unlink(list.files(pattern = '*.xyz'))
  molecules <- list.files(full.names = F, recursive = F, pattern = "xyz_")
  for (molecule in molecules) {
    xyz <- data.frame(read.csv(molecule, header = F, col.names = c('atom','x','y','z')))
    xyz <- data.frame(apply(xyz,2,function(x)gsub('\\s+', '',x)))
    xyz <- xyz[!(nchar(as.character(xyz$atom)) > 2),]
    xyz[,1] <- gsub(".*[^A-Z].*", NA, xyz[, 1])
    xyz <- xyz[xyz$x!='',]
    xyz <- xyz[complete.cases(xyz),]
    suppressMessages(xyz$atom <- plyr::mapvalues(xyz$atom,
                                               from = c("1", "5", "6", "7", "8", "9", "14", "15", "16", "17", "35", "53"),
                                               to = c(
                                                 "H", "B", "C", "N", "O", "F", "Si", "P",
                                                 "S", "Cl", "Br", "I"
                                               )
    ))
    num.atoms <- nrow(xyz)
    m <- as.data.frame(matrix(NA, ncol = 4, nrow = 2))
    m[1, 1] <- num.atoms
    m[is.na(m)] <- ""
    names(m) <- names(xyz)
    xyz <- rbind(m, xyz)
    new_xyz <- knitr::kable(xyz, format = "simple", row.names = F, col.names = NULL, align = "r")
    new_xyz <- new_xyz[-1]
    new_xyz <- new_xyz[-length(new_xyz)]
    write(new_xyz, paste(stringr::str_remove(tools::file_path_sans_ext(molecule), 'xyz_'), ".xyz", sep = ""))
  }
  setwd("..")
}


coor.trans <- function(molecule, coor.atoms) {
  atoms <- strsplit(coor.atoms, " ")
  unlisted.atoms <- unlist(atoms)
  numeric.atoms <- as.numeric(unlisted.atoms)
  xyz <- data.table::fread(molecule, header = F)
  mag <- function(vector) {
    sqrt(vector[[1]]^2 + vector[[2]]^2 + vector[[3]]^2)
  }
  if (length(numeric.atoms) == 4) {
    new_origin <- (xyz[numeric.atoms[[1]], 2:4] + xyz[numeric.atoms[[2]], 2:4])/2
    new_y <- as.numeric((xyz[numeric.atoms[[3]], 2:4] - new_origin) /
                          mag(xyz[numeric.atoms[[3]], 2:4] - new_origin))
    coplane <- as.numeric((xyz[numeric.atoms[[4]], 2:4] - new_origin) /
                            mag(xyz[numeric.atoms[[4]], 2:4] - new_origin))
  } else {
    new_origin <- xyz[numeric.atoms[[1]], 2:4]
    new_y <- as.numeric((xyz[numeric.atoms[[2]], 2:4] - new_origin) /
                          mag(xyz[numeric.atoms[[2]], 2:4] - new_origin))
    coplane <- as.numeric((xyz[numeric.atoms[[3]], 2:4] - new_origin) /
                            mag(xyz[numeric.atoms[[3]], 2:4] - new_origin))
  }
  cross_y_coplane <- pracma::cross(coplane, new_y)
  coef_mat <- aperm(array(c(
    new_y,
    coplane,
    cross_y_coplane
  ),
  dim = c(3, 3)
  ))
  angle_new.y_coplane <- matlib::angle(coplane, new_y, degree = F)
  x_ang_new.y <- pi / 2
  cop_ang_x <- angle_new.y_coplane - x_ang_new.y
  result_vec <- c(0, cos(cop_ang_x), 0)
  new_x <- solve(coef_mat, result_vec)
  new_z <- pracma::cross(new_x, new_y)
  new_basis <- aperm(array(c(new_x, new_y, new_z), dim = c(3, 3)))
  new_origin <- xyz[numeric.atoms[[1]], 2:4]
  new_coordinates <- matrix(nrow = dim(xyz)[[1]], ncol = 3)
  transformed_coordinates <- matrix(nrow = dim(xyz)[[1]], ncol = 3)
  for (i in 1:dim(xyz)[[1]]) {
    new_coordinates[i, ] <- as.numeric(xyz[i, 2:4] - new_origin)
    transformed_coordinates[i, ] <- aperm(new_basis %*% new_coordinates[i, ])
  }
  transformed_coordinates <- round(transformed_coordinates, 4)
  elements <- xyz[, 1]
  transformed_coordinates <- cbind(elements, transformed_coordinates)
  num.atoms <- nrow(transformed_coordinates)
  m <- as.data.frame(matrix(NA, ncol = 4, nrow = 2))
  m[1, 1] <- num.atoms
  m[is.na(m)] <- ""
  names(m) <- names(transformed_coordinates)
  transformed_coordinates <- rbind(m, transformed_coordinates)
  transformed_coordinates[transformed_coordinates == "0"] <- "0.0"
  new_xyz <- knitr::kable(transformed_coordinates,
                          format = "simple", row.names = F, col.names = NULL
  )
  new_xyz <- new_xyz[-1]
  new_xyz <- new_xyz[-length(new_xyz)]
  write(new_xyz, paste(tools::file_path_sans_ext(molecule), "_tc", ".xyz", sep = ""))
}


steRimol <- function(mol.dir, coordinates, radii = 'CPK', only.sub = T) {
  tryCatch(
    expr = {
      origin <- as.numeric(unlist(strsplit(coordinates, " "))[[1]])
      direction <- as.numeric(unlist(strsplit(coordinates, " "))[[2]])
      bondi <- data.frame(matrix(nrow = 12, ncol = 2))
      bondi[, 1] <- c("H", "B", "C", "N", "O", "F", "Si", "P", "S", "Cl", "Br", "I")
      bondi[, 2] <- c(1.09, 1.92, 1.70, 1.55, 1.52, 1.47, 2.10, 1.80, 1.80, 1.75, 1.83, 1.98)
      colnames(bondi) <- c("Atom", "Radius")
      Paton.Atypes <- data.frame(c("C", "C2", "C3", "C4", "C5/N5", "C6/N6", "C7", "C8", "H", "N", "C66", "N4", "O", "O2", "P", "S", 'S.O', "S1", "F", "Cl", "S4", "Br", "I"), 
                                 c(1.50,1.60,1.60,1.50,1.70,1.70,1.70,1.50,1.00,1.50,1.70,1.45,1.35,1.35,1.40,1.70,1.70,1.00,1.35,1.80,1.40,1.95,2.15))
      colnames(Paton.Atypes) <- c("Atom", "Radius")
      Paton.Atypes <- rbind(Paton.Atypes, bondi[!bondi$Atom %in% Paton.Atypes$`Atom`,])
      xyz_file_generator(mol.dir)
      setwd(mol.dir)
      bonds <- unique(data.table::fread(list.files(pattern = "bonds")))
      bonds <- data.frame(sapply(bonds, as.numeric))
      if (is.na(bonds[bonds$V1 == direction, ][1, 2])) {
        coordinates <- paste(coordinates, as.character(bonds[bonds$V2 == direction, ][1, 1]), sep = " ")
      } else {
        coordinates <- paste(coordinates, as.character(bonds[bonds$V1 == direction, ][1, 2]), sep = " ")
      }
      if (as.numeric(unlist(strsplit(coordinates, " "))[[3]]) == origin) {
        coordinates <- as.numeric(unlist(strsplit(coordinates, " "))[1:2])
        coordinates <- paste(as.character(coordinates[1]), as.character(coordinates[2]), sep = ' ')
        if (is.na(bonds[bonds$V1 == direction, ][1, 2])) {
          coordinates <- paste(coordinates, as.character(bonds[bonds$V2 == direction, ][2, 1]), sep = " ")
        } else {
          coordinates <- paste(coordinates, as.character(bonds[bonds$V1 == direction, ][2, 2]), sep = " ")
        }
      }
      if (unlist(strsplit(coordinates, " "))[3] == 'NA') {
        coordinates <- as.numeric(unlist(strsplit(coordinates, " "))[1:2])
        coordinates <- paste(as.character(coordinates[1]), as.character(coordinates[2]), sep = ' ')
        remove.direction <- bonds[bonds$V2 != direction, ]
        if (!is.na(remove.direction[remove.direction$V1 == origin, ][1, 2])) {
          coordinates <- paste(coordinates, as.character(remove.direction[remove.direction$V1 == origin, ][1, 2]), sep = " ")
        } else {
          coordinates <- paste(coordinates, as.character(remove.direction[remove.direction$V1 == origin, ][1, 2]), sep = " ")
        }
      }
      coor.trans(list.files(pattern = ".xyz"), coordinates)
      mag <- function(vector) {
        sqrt(vector[[1]]^2 + vector[[2]]^2)
      }
      substi <- data.table::fread(list.files(pattern = "tc.xyz"))
      substi <- tibble::rownames_to_column(substi)
      if (only.sub == T) {
        G <- igraph::graph.data.frame(bonds, directed = T)
        C <- igraph::all_simple_paths(G, as.character(origin), mode = "all")
        rlev <- vector()
        for (i in 1:length(C)) {
          if (length(C[[i]]) > 2) {
            rlev[[i]] <- stringr::str_extract_all(as.character(C[i]), "`[0-9]{1,3}`")
          }
          if (length(C[[i]]) == 2) {
            two_atoms <- stringr::str_extract_all(as.character(C[i]), "[0-9]{1,3}")[[1]][1:4]
            if (as.character(origin) %in% two_atoms && as.character(direction) %in% two_atoms) {
              rlev[[i]] <- stringr::str_extract_all(as.character(C[i]), "`[0-9]{1,3}`")
            }
          }
        }
        rlev <- rlev[grep(paste("`", direction, "`", sep = ""), rlev)]
        rlev_atoms <- as.numeric(stringr::str_extract_all(unique(unlist(rlev)), "[0-9]{1,3}"))
        substi <- substi[substi$rowname %in% rlev_atoms]
      }
      from_source <- dplyr::intersect(
        bonds[bonds$V1 %in% substi$rowname, ],
        bonds[bonds$V2 %in% substi$rowname, ]
      )
      nms <- data.frame(matrix(nrow = nrow(from_source), ncol = 1))
      colnames(nms) <- "atom"
      for (i in 1:dim(from_source)[1]) {
        nms[i, ] <- substi$V1[substi$rowname == from_source$V1[i]]
      }
      nms.2 <- data.frame(matrix(nrow = nrow(from_source), ncol = 1))
      colnames(nms.2) <- "atom.2"
      for (i in 1:dim(from_source)[1]) {
        nms.2[i, ] <- substi$V1[substi$rowname == from_source$V2[i]]
      }
      from_source <- cbind(nms, from_source, nms.2)
      for (i in as.numeric(unique(as.vector(t(from_source[, -c(1, 4)]))))) {
        if (i %in% from_source$V1 && from_source$atom[from_source$V1 == i] == "H") {
          from_source <- from_source[from_source$V1 != i, ]
        }
        if (i %in% from_source$V2 && from_source$atom.2[from_source$V2 == i] == "H" && from_source$atom[from_source$V2 == i] %in% c("O", "N", "F")) {
          bonded_OH <- from_source$V1[from_source$V2 == i]
          for (j in bonded_OH) {
            bond.length <- sqrt(sum((substi[substi$rowname == i, 3:5] - substi[substi$rowname == j, 3:5])^2))
            if (bond.length > 1.6) {
              from_source <- from_source[from_source$V2 != i, ]
            }
          }
        }
      }
      bonds.clean <- from_source[, 2:3]
      substi <- substi[substi$rowname %in% bonds.clean$V1 | substi$rowname %in% bonds.clean$V2, ]
      substi <- plyr::mutate(substi, magnitude = mag(substi[, c(3, 5)]))
      substi <- plyr::mutate(substi, Radius = rep(0, nrow(substi)))
      atypes <- data.table::fread(list.files(pattern = 'atypes'), header = F)
      atypes <- atypes[row.names(atypes) %in% substi$rowname]
      trans.table <- data.frame(
        c("O.2","O.3",'O.co2',"C.1","C.2","C.cat",'C.3','C.ar','N.2','N.1','N.3','N.ar','N.am','N.pl3','N.4','S.2','S.3','S.O2','P.3'), 
        c("O2","O",'O','C3','C2',"C3",'C','C6/N6','C6/N6','N','C6/N6','C6/N6','C6/N6','C6/N6','N',"S",'S4','S1','P'))
      names(trans.table) <- c('mol2', 'Verloop')
      for (i in 1:nrow(atypes)) {
        if (atypes[i, ] %in% trans.table$mol2) {
          atypes[i, ] <- trans.table$Verloop[which(trans.table$mol2 %in% atypes[i, ])]
        }
      }
      substi <- plyr::mutate(substi, atypes = atypes$V1)
      for (i in 1:dim(substi)[1]) {
        if (radii == 'bondi') {
          substi$Radius[i] <- bondi$Radius[bondi$Atom == substi$V1[i]]
        }
        if (radii == 'CPK') {
          substi$Radius[i] <- Paton.Atypes$Radius[Paton.Atypes$Atom == substi$atypes[i]]
        }
      }
      substi <- plyr::mutate(substi, Bs = substi$magnitude + substi$Radius)
      substi <- plyr::mutate(substi, L = substi$V3 + substi$Radius)
      scans <- 90 / 5
      deg.list <- seq(scans, 90, scans)
      plane <- substi[, c(3, 5)]
      b1s <- vector()
      for (i in deg.list) {
        rot.mat <- matrix(ncol = 2, nrow = 2)
        co.deg <- cos(i * (pi / 180))
        si.deg <- sin(i * (pi / 180))
        rot.mat[1, ] <- c(co.deg, -1 * si.deg)
        rot.mat[2, ] <- c(si.deg, co.deg)
        ind <- NULL
        tc <- matrix(nrow = dim(plane)[[1]], ncol = 2)
        for (i in 1:dim(plane)[[1]]) {
          tc[i, ] <- aperm(rot.mat %*% as.numeric(plane[i, ]))
        }
        tc <- round(tc, 3)
        avs <- abs(c(
          max(tc[, 1]),
          min(tc[, 1]),
          max(tc[, 2]),
          min(tc[, 2])
        ))
        if (min(avs) == 0) {
          if (any(which(avs == min(avs)) %in% c(1, 2))) {
            tc <- round(tc, 1)
            B1 <- max(substi$Radius[which(tc[, 1] == 0, arr.ind = T)])
            b1s <- append(b1s, B1)
          }
          if (any(which(avs == min(avs)) %in% c(3, 4))) {
            tc <- round(tc, 1)
            B1 <- max(substi$Radius[which(tc[, 2] == 0, arr.ind = T)])
            b1s <- append(b1s, B1)
          }
        } else {
          if (any(which(avs == min(avs)) %in% c(1, 2))) {
            ind <- (which(abs(tc[, 1]) == min(avs), arr.ind = T))[1]
            against <- vector()
            if (any(tc[ind, 1] < 0)) {
              new.ind <- which(tc[, 1] == min(tc[, 1]), arr.ind = T)
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 1], tc[new.ind[1], 1], tc[new.ind[1], 1] + 1))
              tc[,1] <- -tc[,1]
            } else {
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 1], tc[ind[1], 1] - 1, tc[ind[1], 1]))
            }
            for (i in 2:dim(tc)[1]) {
              if (tc[i, 3] == T) {
                against <- append(against, tc[i, 1] + substi$Radius[i])
              }
              B1 <- ifelse(length(against) > 0, max(against), abs(tc[ind[1], 1]) + substi$Radius[ind[1]])
            }
            b1s <- append(b1s, B1)
          }
          if (any(which(avs == min(avs)) %in% c(3, 4))) {
            ind <- (which(abs(tc[, 2]) == min(avs), arr.ind = T))[1]
            against <- vector()
            if (any(tc[ind, 2] < 0)) {
              new.ind <- which(tc[, 2] == min(tc[, 2]), arr.ind = T)
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 2], tc[new.ind[1], 2], tc[new.ind[1], 2] + 1))
              tc[,2] <- -tc[,2]
            } else {
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 2], tc[ind[1], 2] - 1, tc[ind[1], 2]))
            }
            for (i in 2:dim(tc)[1]) {
              if (tc[i, 3] == T) {
                against <- append(against, tc[i, 2] + substi$Radius[i])
              }
              B1 <- ifelse(length(against) > 0, max(against), abs(tc[ind[1], 2]) + substi$Radius[ind[1]])
            }
            b1s <- append(b1s, B1)
          }
        }
      }
      
      back.ang <- deg.list[which(b1s == min(b1s))][1] - scans
      front.ang <- deg.list[which(b1s == min(b1s))][1] + scans
      thin <- seq(back.ang, front.ang, 1)
      
      for (i in thin) {
        rot.mat <- matrix(ncol = 2, nrow = 2)
        co.deg <- cos(i * (pi / 180))
        si.deg <- sin(i * (pi / 180))
        rot.mat[1, ] <- c(co.deg, -1 * si.deg)
        rot.mat[2, ] <- c(si.deg, co.deg)
        ind <- NULL
        tc <- matrix(nrow = dim(plane)[[1]], ncol = 2)
        for (i in 1:dim(plane)[[1]]) {
          tc[i, ] <- aperm(rot.mat %*% as.numeric(plane[i, ]))
        }
        tc <- round(tc, 3)
        avs <- abs(c(
          max(tc[, 1]),
          min(tc[, 1]),
          max(tc[, 2]),
          min(tc[, 2])
        ))
        if (min(avs) == 0) {
          if (any(which(avs == min(avs)) %in% c(1, 2))) {
            tc <- round(tc, 1)
            B1 <- max(substi$Radius[which(tc[, 1] == 0, arr.ind = T)])
            b1s <- append(b1s, B1)
          }
          if (any(which(avs == min(avs)) %in% c(3, 4))) {
            tc <- round(tc, 1)
            B1 <- max(substi$Radius[which(tc[, 2] == 0, arr.ind = T)])
            b1s <- append(b1s, B1)
          }
        } else {
          if (any(which(avs == min(avs)) %in% c(1, 2))) {
            ind <- (which(abs(tc[, 1]) == min(avs), arr.ind = T))[1]
            against <- vector()
            if (any(tc[ind, 1] < 0)) {
              new.ind <- which(tc[, 1] == min(tc[, 1]), arr.ind = T)
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 1], tc[new.ind[1], 1], tc[new.ind[1], 1] + 1))
              tc[,1] <- -tc[,1]
            } else {
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 1], tc[ind[1], 1] - 1, tc[ind[1], 1]))
            }
            for (i in 2:dim(tc)[1]) {
              if (tc[i, 3] == T) {
                against <- append(against, tc[i, 1] + substi$Radius[i])
              }
              B1 <- ifelse(length(against) > 0, max(against), abs(tc[ind[1], 1]) + substi$Radius[ind[1]])
            }
            b1s <- append(b1s, B1)
          }
          if (any(which(avs == min(avs)) %in% c(3, 4))) {
            ind <- (which(abs(tc[, 2]) == min(avs), arr.ind = T))[1]
            against <- vector()
            if (any(tc[ind, 2] < 0)) {
              new.ind <- which(tc[, 2] == min(tc[, 2]), arr.ind = T)
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 2], tc[new.ind[1], 2], tc[new.ind[1], 2] + 1))
              tc[,2] <- -tc[,2]
            } else {
              tc <- plyr::mutate(as.data.frame(tc), "indi" = dplyr::between(tc[, 2], tc[ind[1], 2] - 1, tc[ind[1], 2]))
            }
            for (i in 2:dim(tc)[1]) {
              if (tc[i, 3] == T) {
                against <- append(against, tc[i, 2] + substi$Radius[i])
              }
              B1 <- ifelse(length(against) > 0, max(against), abs(tc[ind[1], 2]) + substi$Radius[ind[1]])
            }
            b1s <- append(b1s, B1)
          }
        }
      }
      B1 <- min(b1s[b1s >= 0])
      B5 <- max(substi$Bs)
      L <- max(substi$L) + 0.4
      result <- unique(round(data.frame(B1, B5, L), 2))
      unlink(list.files(pattern = ".xyz"))
      setwd("..")
      return(result)
    }, warning = function(w) {
      print(getwd())
      message("Something is wrong")
      unlink(list.files(pattern = ".xyz"))
      setwd("..")
    }, error = function(e) {
      print(basename(getwd()))
      message("Something is wrong, stopping steRimol")
      unlink(list.files(pattern = ".xyz"))
      setwd("..")
    }
  )
}

steRimol.df <- function(path, radii = 'CPK', only.sub = T) {
  molecules <- list.dirs(full.names = F, recursive = F)
  coor.atoms <- readline("Primary axis along: ")
  steri.list <- list()
  for (molecule in molecules) {
    steri.list[[match(molecule, molecules)]] <- steRimol(molecule, coor.atoms, radii, only.sub)
  }
  steri.dafr <- data.frame(data.table::rbindlist(steri.list))
  row.names(steri.dafr) <- molecules
  return(steri.dafr)
}

diversitree::set.defaults(steRimol.df, getwd())

